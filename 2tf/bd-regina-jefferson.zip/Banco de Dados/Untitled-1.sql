[
	{
		nome": "Sophia Vitória Daniela Fogaça",
		"idade": 62,
		"cpf": "041.765.818-40",
		"rg": "17.928.563-4",
		"data_nasc": "23/01/1961",
		"sexo": "Feminino",
		"signo": "Aquário",
		"mae": "Nicole Gabriela",
		"pai": "Kaique Anderson Enzo Fogaça",
		"email": "sophia_vitoria_fogaca@yaooll.com",
		"senha": "S3bdosiiRp",
		"cep": "49007-250",
		"endereco": "Rua A",
		"numero": 861,
		"bairro": "Zona de Expansão (Areia Branca)",
		"cidade": "Aracaju",
		"estado": "SE",
		"telefone_fixo": "(79) 3597-1244",
		"celular": "(79) 98837-0030",
		"altura": "1,59",
		"peso": 68,
		"tipo_sanguineo": "A-",
		"cor": "verde"
	},
	{
		"nome": "Rafael Juan Kevin Freitas",
		"idade": 43,
		"cpf": "209.343.599-38",
		"rg": "10.907.021-5",
		"data_nasc": "03/01/1980",
		"sexo": "Masculino",
		"signo": "Capricórnio",
		"mae": "Mariana Luna",
		"pai": "Oliver Marcos Vinicius Roberto Freitas",
		"email": "rafael_freitas@casabellavidros.com.br",
		"senha": "7yM6m8AIBW",
		"cep": "84053-550",
		"endereco": "Rua Ourinhos",
		"numero": 897,
		"bairro": "Nova Rússia",
		"cidade": "Ponta Grossa",
		"estado": "PR",
		"telefone_fixo": "(42) 3700-5175",
		"celular": "(42) 98489-0156",
		"altura": "1,86",
		"peso": 83,
		"tipo_sanguineo": "O+",
		"cor": "laranja"
	},
	{
		"nome": "Maitê Jaqueline Teixeira",
		"idade": 23,
		"cpf": "234.940.257-62",
		"rg": "47.420.526-5",
		"data_nasc": "18/01/2000",
		"sexo": "Feminino",
		"signo": "Capricórnio",
		"mae": "Maya Nair",
		"pai": "Benício Thiago Teixeira",
		"email": "maite_jaqueline_teixeira@dhl.com",
		"senha": "46SRgTm9rT",
		"cep": "22763-587",
		"endereco": "Rua H",
		"numero": 505,
		"bairro": "Cidade de Deus",
		"cidade": "Rio de Janeiro",
		"estado": "RJ",
		"telefone_fixo": "(21) 2945-5457",
		"celular": "(21) 98345-2619",
		"altura": "1,53",
		"peso": 71,
		"tipo_sanguineo": "AB-",
		"cor": "vermelho"
	},
	{
		"nome": "Fátima Lara Barros",
		"idade": 53,
		"cpf": "477.724.966-21",
		"rg": "15.883.118-4",
		"data_nasc": "05/02/1970",
		"sexo": "Feminino",
		"signo": "Aquário",
		"mae": "Silvana Ana",
		"pai": "Leonardo Ricardo Thales Barros",
		"email": "fatima.lara.barros@technew.ind.br",
		"senha": "GlL6Z5mmoA",
		"cep": "68909-519",
		"endereco": "Alameda Setima",
		"numero": 256,
		"bairro": "Boné Azul",
		"cidade": "Macapá",
		"estado": "AP",
		"telefone_fixo": "(96) 3610-9006",
		"celular": "(96) 98480-1593",
		"altura": "1,50",
		"peso": 84,
		"tipo_sanguineo": "O-",
		"cor": "azul"
	},
	{
		"nome": "Lavínia Lúcia Sara Barbosa",
		"idade": 76,
		"cpf": "799.007.021-90",
		"rg": "17.755.328-5",
		"data_nasc": "23/01/1947",
		"sexo": "Feminino",
		"signo": "Aquário",
		"mae": "Analu Emily Laís",
		"pai": "Lucas Juan Barbosa",
		"email": "lavinialuciabarbosa@fileno.com.br",
		"senha": "rLc31UbpZm",
		"cep": "88316-620",
		"endereco": "Rua José Carlos da Silva",
		"numero": 937,
		"bairro": "Itaipava",
		"cidade": "Itajaí",
		"estado": "SC",
		"telefone_fixo": "(47) 2582-0195",
		"celular": "(47) 98484-8995",
		"altura": "1,68",
		"peso": 66,
		"tipo_sanguineo": "B+",
		"cor": "amarelo"
	}
]



select *from tesouro_diretofundo_investimentoINSERT INTO `mydb`.`usuario`

10580.61
36463.4
2618.89
22606.98
49435.87

"Rua A numero 861, Zona de Expansão (Areia Branca)- Aracaju, SE."
"Rua Ourinhos numero 897, Nova Rússia- Ponta Grossa, PR."
"Rua H numero 505, Cidade de Deus- Rio de Janeiro, RJ."
"Alameda Setima numero 256, Boné Azul- Macapá, AP."
"Rua José Carlos da Silva numero 937, Itaipava- Itajaí, SC."



0
1
2
3
4





Conta Corrente
0773690-8
Agência
6981
Banco
HSBC Bank Brasil S.A. – Banco Múltiplo 399 


Conta Corrente
14545-3
Agência
8610
Banco
Itaú Unibanco Holding S.A 652 


Conta Corrente
0545141-8
Agência
6380
Banco 
Itaú S.A. 341 


Conta Corrente
0768006-6
Agência
2558
Banco
Bradesco 237 


Conta Corrente
90433-3
Agência
1803
Banco
Banco do Brasil 001 



